while True:
  antwoord = input("quit")
  if antwoord == "quit":
        quit()
  else:
      continue