i  = 50 
while i <= 1000:
    print('50 +',i - 50,'=', i )
    i = i + 50 
    import time
    time.sleep(1)
